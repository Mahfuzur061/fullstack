# Cinema-XX

***
**Server:**
- IP: http://54.163.59.2/
- Domain: http://jazzymcjazz.dk/ (owned by Lars)
- Swagger: 
  - http://54.163.59.2/swagger-ui/index.html
  - http://jazzymcjazz.dk/swagger-ui/index.html
***

**"Funny" GitHub Names**
 - Lars Riel: JazzyMcJazz
 - Chris Millington: JamesBond87
***
 **Lars**
 
Acting as technical lead on the project have 
mainly been in charge of setting up AWS pipeline, 
managing git and doing testing. I have also completed
a few of the simpler user stories/endpoints and helped 
team members polish up their code.

***
**Alex**

Responsible for designing and implementing the ERD (Together with Peri).
Lead developer on Security Branch (Implmenting Spring security with JWT).    
 
***
**Peri**

Designing and implementing the ERD (With Alex).Implement mainly  endpoints 1,2 and 6 .
I have also done some pair coding with Lars and Alex!

***
**Chris**
Was the Scrum master throughout the two sprints and had originally coded endpoint 4. Was also 
in charge of putting together all required documentation and worked with Lars on endpoint


**Mahfuzur**
- Sprint 1: Gathered informations about movie and details and put it on a spreadsheet of excel. Solved the Endponit- 4 with collaboration with chris
- Sprint 2: Gathered more informations , trailers, posters and images and added to the program to get movie inf
