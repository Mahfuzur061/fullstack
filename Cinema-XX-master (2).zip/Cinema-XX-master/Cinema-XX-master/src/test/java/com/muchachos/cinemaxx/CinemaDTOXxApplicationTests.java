package com.muchachos.cinemaxx;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CinemaDTOXxApplicationTests {

    @Test
    void contextLoads() {
    }

}
