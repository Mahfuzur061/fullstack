package com.muchachos.cinemaxx.Security.User.DTO;


import lombok.Data;
@Data
public class UserResponse {

    private String id;
    private String username;

}