package com.muchachos.cinemaxx;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CinemaXxApplication {

    // fake comment ...
    public static void main(String[] args) {
        SpringApplication.run(CinemaXxApplication.class, args);
    }

}